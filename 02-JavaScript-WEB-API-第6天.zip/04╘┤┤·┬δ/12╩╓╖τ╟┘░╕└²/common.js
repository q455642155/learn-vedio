//根据id获取对应的元素
function my$(id) {
    return document.getElementById(id);
}




